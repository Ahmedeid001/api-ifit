<?php

namespace App\Http\Controllers\api;
use App\Models\Articale;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
 

class articalecontroller extends Controller
{
    public function index()
    {
        $articales= Articale::all();
        if($articales->count()>0){

            return response()->json([
                'status'=>200,
                'data'=>$articales
            ],200);
        }else{
            return response()->json([
                'status'=>404,
                'message'=>'not found'
            ],200);

        }
    }
}