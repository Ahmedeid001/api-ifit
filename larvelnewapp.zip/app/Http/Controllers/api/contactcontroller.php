<?php

namespace App\Http\Controllers\api;
//use App\Models\validator;
use App\Http\Controllers\Controller;
use App\Models\contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class contactcontroller extends Controller
{
    public function store(Request $request){
        $validator= validator::make($request->all(),[
            'name'=>'required|string|max:20',
            'email'=>'required|email|max:20',
            'phone'=>'required|digits:12',
           'message'=>'required|max:200',
    
         ]);
         if($validator->fails()){
            return response()->json([
                'status'=>422,
                'errors'=>$validator->messages()
            ],422);
         }else{
            $contact=Contact::create($request->all());
            //$contact= Contact::create($request->all());
         }
            if($contact){
                return response()->json([
                'status'=>200,
                'message'=>'message sent successfully'
                ],200);
            }else{
                return response()->json([
                   'status'=>500,
                   'message'=>'message not sent'
                ],500);
            }
    }
}
